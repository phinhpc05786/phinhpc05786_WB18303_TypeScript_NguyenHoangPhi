console.log("----------Câu 1-----------");
console.log("-1.1");
var number1 = 5;
var number2 = 2.6;
var phrase = "result is ";
var permit = true;
var result = number1 + number2;
if (permit) {
    console.log(phrase + result);
}
else {
    console.log('not show result');
}

