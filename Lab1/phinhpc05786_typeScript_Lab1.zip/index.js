console.log("-----Câu 1------");
console.log("HelloHelloWorld");
console.log("-----Câu 2------");
var a = 1;
var b = 2;
console.log(a + b);
console.log("-----Câu 4------");
