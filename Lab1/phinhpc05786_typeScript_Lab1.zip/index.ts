console.log("-----Câu 1------");

console.log("HelloHelloWorld");

console.log("-----Câu 2------");

let a : number = 1;
let b : number = 2;

console.log(a + b);

console.log("-----Câu 3------");
